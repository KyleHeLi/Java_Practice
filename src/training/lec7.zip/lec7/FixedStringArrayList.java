package training.lec7;

public class FixedStringArrayList {
    String[] elements;
    int size;
    int capacity;
}
