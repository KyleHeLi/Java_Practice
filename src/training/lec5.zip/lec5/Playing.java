package training.lec5;

public interface Playing {
    public abstract void play();
}
