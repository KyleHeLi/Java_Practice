package training.lec5;

public interface Movement {
    public final static String CONSTNTS = "Animals' movement";
    public abstract void running(); // key word 'abstract' can be removed
    public abstract void jumping();
}
