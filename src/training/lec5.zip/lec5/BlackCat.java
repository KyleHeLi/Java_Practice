package training.lec5;

public class BlackCat extends Cat {
}
