package training.lec4;

public class Operators {
    public static void main(String[] args) {
        // +, -, *, /, %

        // &&(and), ||(or), !(not), >=, >, <=, <, ==, !=
        int a = 9;
        if (a == 10) {
            System.out.println("a is not 9");
        }

        // instanceof
        Integer b = 1;
        System.out.println(b instanceof Integer);
    }
}
