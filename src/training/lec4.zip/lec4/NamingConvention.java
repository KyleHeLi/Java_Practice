package training.lec4;

// class name
// first character a-zA-Z
// except first character a-zA-Z_0-9
public class NamingConvention {
    // constant
    public static int MAX_NUMBER = 9999999;

    // camel case
    String studentName;
    String aString;

    public void printSomething() {

    }

    // snake case
    String student_name;
}
