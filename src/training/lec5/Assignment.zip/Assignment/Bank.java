package training.lec5.Assignment;

public class Bank {
    Account[] accounts = new Account[10];
}
